package sh;

public class Main {
	
	
	public static void main(String[] args) throws InterruptedException {
        Fibonacci fibo = new Fibonacci();
        Thread t = new Thread(fibo);
        Table tab = new Table();
        Thread t2 = new Thread(tab);
        t.start();
        t.join();
        t2.start();
    }
}
